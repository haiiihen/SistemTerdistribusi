package app.UDP;

public class Config {
    public static final String HOST = "127.0.0.1";
    public static final int PORT = 5000;
    public static final int MAX_BYTE = 1024;
}